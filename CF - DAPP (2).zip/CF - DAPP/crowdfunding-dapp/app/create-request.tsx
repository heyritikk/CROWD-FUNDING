import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { utils } from 'ethers' // Importing ethers.js for address validation

interface CreateRequestProps {
  onCreateRequest: (description: string, recipient: string, value: string) => void;
}

export default function CreateRequest({ onCreateRequest }: CreateRequestProps) {
  const [description, setDescription] = useState("")
  const [recipient, setRecipient] = useState("")
  const [value, setValue] = useState("")
  const [error, setError] = useState("") // State to hold error messages

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Basic address validation
    if (!utils.isAddress(recipient)) {
      setError("Invalid Ethereum address")
      return
    }

    setError("") // Clear any previous error
    onCreateRequest(description, recipient, value)
    setDescription("")
    setRecipient("")
    setValue("")
  }

  return (
    <Card className="w-full max-w-md mt-4 bg-white bg-opacity-90 backdrop-blur-lg">
      <CardHeader>
        <CardTitle>Create Spending Request</CardTitle>
      </CardHeader>
      <CardContent>
        {error && <p className="text-red-500">{error}</p>} {/* Display error message */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter request description"
              required
            />
          </div>
          <div>
            <Label htmlFor="recipient">Recipient Address</Label>
            <Input
              id="recipient"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="Enter recipient's Ethereum address"
              required
            />
          </div>
          <div>
            <Label htmlFor="value">Value (ETH)</Label>
            <Input
              id="value"
              type="number"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="Enter amount in ETH"
              required
            />
          </div>
          <Button type="submit">Create Request</Button>
        </form>
      </CardContent>
    </Card>
  )
}
