export default function BackgroundAnimation() {
    return (
      <div className="background-animation">
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
      </div>
    )
  }