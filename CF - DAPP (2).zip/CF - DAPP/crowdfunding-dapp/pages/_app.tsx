"use client"

import { useState, useEffect } from 'react'
import { ethers } from 'ethers'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import CreateRequest from '@/app/create-request';

import BackgroundAnimation from '@/app/background-animation'

// Simulated contract ABI (this would normally come from your compiled contract)
const contractABI = [
  "function sendEth() public payable",
  "function getContractBalance() public view returns(uint)",
  "function refund() public",
  "function createRequests(string memory _description, address payable _recipient, uint _value) public",
  "function voteRequest(uint _requestNo) public",
  "function makePayment(uint _requestNo) public"
]

export default function App() {
  const [account, setAccount] = useState("")
  const [contract, setContract] = useState(null)
  const [balance, setBalance] = useState("0")
  const [contribution, setContribution] = useState("")
  const [requests, setRequests] = useState([])

  useEffect(() => {
    const init = async () => {
      if (typeof window.ethereum !== 'undefined') {
        try {
          // Request account access
          await window.ethereum.request({ method: 'eth_requestAccounts' })
          const provider = new ethers.providers.Web3Provider(window.ethereum)
          const signer = provider.getSigner()
          const address = await signer.getAddress()
          setAccount(address)

          // Replace with the actual deployed contract address
          const contractAddress = "0xd3bB49346E4C34B9dB2841706A88B477A9b5F720"
          const crowdFundingContract = new ethers.Contract(contractAddress, contractABI, signer)
          setContract(crowdFundingContract)

          // Get initial balance
          const initialBalance = await crowdFundingContract.getContractBalance()
          setBalance(ethers.utils.formatEther(initialBalance))
        } catch (error) {
          console.error("An error occurred:", error)
        }
      } else {
        console.log("Please install MetaMask!")
      }
    }

    init()
  }, [])

  const handleContribute = async () => {
    if (contract && contribution) {
      try {
        const tx = await contract.sendEth({ value: ethers.utils.parseEther(contribution) })
        await tx.wait()
        const newBalance = await contract.getContractBalance()
        setBalance(ethers.utils.formatEther(newBalance))
        setContribution("")
      } catch (error) {
        console.error("Error contributing:", error)
      }
    }
  }

  const handleRefund = async () => {
    if (contract) {
      try {
        const tx = await contract.refund()
        await tx.wait()
        const newBalance = await contract.getContractBalance()
        setBalance(ethers.utils.formatEther(newBalance))
      } catch (error) {
        console.error("Error refunding:", error)
      }
    }
  }

  const handleCreateRequest = async (description, recipient, value) => {
    if (contract) {
      try {
        const tx = await contract.createRequests(description, recipient, ethers.utils.parseEther(value))
        await tx.wait()
        // In a real scenario, you'd fetch the updated requests from the contract
        setRequests([...requests, { description, recipient, value, completed: false, noOfVoters: 0 }])
      } catch (error) {
        console.error("Error creating request:", error)
      }
    }
  }

  const handleVote = async (requestNo) => {
    if (contract) {
      try {
        const tx = await contract.voteRequest(requestNo)
        await tx.wait()
        // Update the number of voters for the specified request
        const updatedRequests = [...requests]
        updatedRequests[requestNo].noOfVoters++
        setRequests(updatedRequests)
      } catch (error) {
        console.error("Error voting:", error)
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <BackgroundAnimation />
      <div className="z-10">
        <Card className="w-full max-w-md bg-white bg-opacity-90 backdrop-blur-lg">
          <CardHeader>
            <CardTitle>CrowdFunding Campaign</CardTitle>
            <CardDescription>Connected Account: {account}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="balance">Contract Balance</Label>
                <Input id="balance" value={`${balance} ETH`} readOnly />
              </div>
              <div>
                <Label htmlFor="contribution">Contribution Amount (ETH)</Label>
                <Input
                  id="contribution"
                  type="number"
                  value={contribution}
                  onChange={(e) => setContribution(e.target.value)}
                  placeholder="Enter amount in ETH"
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button onClick={handleContribute}>Contribute</Button>
            <Button onClick={handleRefund} variant="outline">Refund</Button>
          </CardFooter>
        </Card>

        <Card className="w-full max-w-md mt-4 bg-white bg-opacity-90 backdrop-blur-lg">
          <CardHeader>
            <CardTitle>Spending Requests</CardTitle>
          </CardHeader>
          <CardContent>
            {requests.map((request, index) => (
              <div key={index} className="mb-4 p-4 border rounded">
                <p><strong>Description:</strong> {request.description}</p>
                <p><strong>Recipient:</strong> {request.recipient}</p>
                <p><strong>Value:</strong> {request.value} ETH</p>
                <p><strong>Votes:</strong> {request.noOfVoters}</p>
                <Button onClick={() => handleVote(index)} className="mt-2">Vote</Button>
              </div>
            ))}
          </CardContent>
        </Card>

        <CreateRequest onCreateRequest={handleCreateRequest} />
      </div>
    </div>
  )
}
